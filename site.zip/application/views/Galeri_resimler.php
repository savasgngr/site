﻿    <div class="content_area">
      <div class="main_content floatleft">
       
		
			 
			 
			  <?php foreach($gresimler as $rs ){?>
				<li style="list-style-type: none;">
			  <img style='max-height: 100%; max-width: 100%; object-fit: contain' class="img-center" src="<?=base_url()?>/uploads/galeriresimler/<?=$rs->resim?>"> <span class="overlay"></span> </a>
				</li>
				<br/>
			
			  <?php } ?>
          
		
          
			
			
    
      </div>