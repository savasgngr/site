﻿<section id="contentSection">  
  
	 <div class="main_content floatleft">
      
			<div>
			<p><h1><strong>Hakkımızda</strong></h1></p>
			
			<p><h3><strong><?=$veri[0]->hakkimizda?></strong></h2></p>
			
			</div>
	  
     </div>
       
   
	  </section>